(() => {
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  if (toggle && nav) toggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    toggle.setAttribute('aria-expanded', String(open));
    toggle.textContent = open ? '×' : '☰';
  });
  document.querySelectorAll('[data-year]').forEach(el => el.textContent = new Date().getFullYear());
  const form = document.getElementById('enquiry-form');
  if (form) form.addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(form);
    const subject = encodeURIComponent('Growify enquiry — ' + (data.get('interest') || 'General enquiry'));
    const body = encodeURIComponent(
      'Name: ' + data.get('name') + '\n' +
      'Work email: ' + data.get('email') + '\n' +
      'Company: ' + (data.get('company') || 'Not provided') + '\n' +
      'Area: ' + data.get('interest') + '\n\n' +
      'Challenge:\n' + (data.get('message') || 'Not provided') + '\n\n' +
      'Note: This message was prepared by a website concept form.'
    );
    const status = document.getElementById('form-status');
    status.textContent = 'Your email app should open with the enquiry prepared. Confirm the official recipient before launch.';
    window.location.href = 'mailto:hello@growify.in?subject=' + subject + '&body=' + body;
  });
})();
